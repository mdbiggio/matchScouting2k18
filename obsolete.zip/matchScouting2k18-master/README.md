# matchScouting
Match scouting app that runs on an 8 inch tablets to be used at an FRC Competition
